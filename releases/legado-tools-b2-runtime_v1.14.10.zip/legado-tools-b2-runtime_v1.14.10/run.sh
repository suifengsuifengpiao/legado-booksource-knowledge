#!/usr/bin/env bash
# =============================================================================
# run.sh —— B2 运行时包入口（解压即跑，无需构建）
#
# 本脚本把包内路径喂给 harness/build-cp.sh 的四个环境变量，然后直接运行
# 已编译好的 b2-out/。所有类源自 Legado 3.25 APK，无外部选择器/Rhino jar。
# =============================================================================
set -euo pipefail

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

export DEX_DIR="$HERE/jars"
export FIX_JAR="$HERE/jars/xpath-fix-enjarify.jar"
export STUB_JAR="$HERE/android-stub.jar"
export OUT_DIR="$HERE/b2-out"
export RHINO_RES_JAR="$HERE/rhino-resources.jar"   # Rhino 本地化资源（dex2jar 会丢，必须带）

CP="$(bash "$HERE/harness/build-cp.sh" 2>/dev/null)"
if [ -z "$CP" ]; then
  echo "ERROR: build-cp.sh 未输出 classpath" >&2
  exit 1
fi

# 无参 → 默认 B2Harness 全规则区；首参含 '.' → 视为主类
if [ "$#" -eq 0 ]; then
  MAIN="b2.B2Harness"; ARGS=()
elif [[ "$1" != -* ]] && [[ "$1" == *.* ]]; then
  MAIN="$1"; shift; ARGS=("$@")
else
  MAIN="b2.B2Harness"; ARGS=("$@")
fi

exec java -noverify -Db2.home="$HERE/harness" -cp "$CP" "$MAIN" "${ARGS[@]}"
