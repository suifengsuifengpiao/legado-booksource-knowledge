# legado-tools-b2-runtime v1.14.10 — B2 真机引擎运行时包

**解压即跑，不用构建。** 在纯 JVM 里加载 Legado 3.25 APK 的**真实** `AnalyzeRule` 解析类，用真机同款引擎跑书源规则。

## 快速开始

```bash
unzip legado-tools-b2-runtime_v1.14.10.zip -d .
cd legado-tools-b2-runtime_v1.14.10

# 主回归：四规则区 12 条
bash run.sh 2>&1 | grep -o '{"engine".*'

# 期望： "summary": {"total": 12, "ok": 12, "failed": 0}
```

单独跑某个区域：

```bash
bash run.sh --source /path/to/书源.json --sample-dir harness/samples --region ruleToc
```

跑 xpath/jsonpath 探针（判断 enjarify 修复是否在位）：

```bash
bash run.sh b2.XpathProbe
# 期望：xpath 6/6、jsonpath 2/2 全 ok=true
```

## 包里有什么

| 路径 | 内容 |
|---|---|
| `jars/classes.jar` `classes2.jar` `classes3.jar` `classes4.jar` | 从 APK 4 个 dex 转出的真实类（dex2jar 2.4） |
| `jars/xpath-fix-enjarify.jar` | enjarify 重导的干净覆盖包（救活 xpath / jsonpath），**必须排在 4 个 dex jar 之前** |
| `b2-out/` | 已编译的 harness 类（11 个），无需再编译 |
| `android-stub.jar` | 最小 Android 桩（24 类），补 `Context/Log/Uri/Build` 等 |
| `harness/` | harness 源码 + `build-cp.sh` + `run.sh` + `samples/`，要改逻辑时用 |
| `BUILD.md` | **从零重建的完整操作步骤**（dex2jar/enjarify 命令、两个已知坑的判别特征、验证方法） |

## 能力与边界

| 模式 | 保真度 |
|---|---|
| jsoup（CSS） | 真机级，12/12 |
| `@js:` / `<js>`（Rhino） | 真机级，5/5（含 `java.md5Encode` 等绑定） |
| xpath | 真机级，6/6（含属性轴/后代轴/父子轴） |
| jsonpath | 真机级，2/2 |

**红线**：零外部选择器/Rhino jar（全部类源自 APK）；网络硬短路（`NetworkStub` 注入样本，`unshare -n` 隔离网络实测仍 12/12）。

**边界（诚实说明）**：
- 不联网，只解析你注入的样本 HTML/JSON；真实抓取请回真机。
- Android 层是自产桩，不是真 Android Runtime（解析行为不受影响）。
- 不覆盖动态渲染：需执行 JS 才出内容的页面拿不到渲染后 DOM。

## 版权说明

`jars/` 内的类由 GPL 开源的 [Legado](https://github.com/gedoor/legado) 3.25 APK 转换而来，仅用于本项目的书源调试，随本项目一同按 GPL 精神分发，不构成独立商业分发。若你需要自己重建，见 `BUILD.md`。
